
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | ~> 2.14 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | 2.99.0 |
| <a name="provider_random"></a> [random](#provider\_random) | 3.4.3 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_APP_QUA"></a> [APP\_QUA](#module\_APP\_QUA) | ../modules/virtual_machine_windows_qua | n/a |
| <a name="module_BATCH_QUA"></a> [BATCH\_QUA](#module\_BATCH\_QUA) | ../modules/virtual_machine_windows_identity_qua | n/a |
| <a name="module_FTP_QUA"></a> [FTP\_QUA](#module\_FTP\_QUA) | ../modules/virtual_machine_windows_qua | n/a |
| <a name="module_ResourceGroup"></a> [ResourceGroup](#module\_ResourceGroup) | ../modules/resource_group_data | n/a |
| <a name="module_Subnet"></a> [Subnet](#module\_Subnet) | ../modules/subnet_data | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_managed_disk.data_disk_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_managed_disk.data_disk_batch](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_managed_disk.data_disk_ftp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/managed_disk) | resource |
| [azurerm_virtual_machine_data_disk_attachment.diskassociate_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_data_disk_attachment) | resource |
| [azurerm_virtual_machine_data_disk_attachment.diskassociate_batch](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_data_disk_attachment) | resource |
| [azurerm_virtual_machine_data_disk_attachment.diskassociate_ftp](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_machine_data_disk_attachment) | resource |
| [random_password.password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_azure_region"></a> [azure\_region](#input\_azure\_region) | define the azure region where the resource is deployed (Azure convention) | `string` | `""` | no |
| <a name="input_rg_name"></a> [rg\_name](#input\_rg\_name) | n/a | `string` | `""` | no |
| <a name="input_subscription_id"></a> [subscription\_id](#input\_subscription\_id) | indicate the ID of subscription (Azure context) | `string` | `""` | no |
| <a name="input_tag_cost_center"></a> [tag\_cost\_center](#input\_tag\_cost\_center) | n/a | `string` | `""` | no |
| <a name="input_tag_deployment_method"></a> [tag\_deployment\_method](#input\_tag\_deployment\_method) | n/a | `string` | `""` | no |
| <a name="input_tag_entity"></a> [tag\_entity](#input\_tag\_entity) | define the name of the entity (LVMH trigram) | `string` | `""` | no |
| <a name="input_tag_environment"></a> [tag\_environment](#input\_tag\_environment) | define the environment | `string` | `""` | no |
| <a name="input_tag_index"></a> [tag\_index](#input\_tag\_index) | define the index of the resource | `string` | `""` | no |
| <a name="input_tag_location"></a> [tag\_location](#input\_tag\_location) | define the azure region where the resource is deployed (LVMH code) | `string` | `""` | no |
| <a name="input_tag_msp"></a> [tag\_msp](#input\_tag\_msp) | n/a | `string` | `""` | no |
| <a name="input_tag_owner"></a> [tag\_owner](#input\_tag\_owner) | n/a | `string` | `""` | no |
| <a name="input_tag_project"></a> [tag\_project](#input\_tag\_project) | define the name of the project | `string` | `""` | no |
| <a name="input_tag_role"></a> [tag\_role](#input\_tag\_role) | n/a | `string` | `""` | no |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | indicate the ID of Azure tenant (Azure context) | `string` | `""` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_AdminPassword"></a> [AdminPassword](#output\_AdminPassword) | n/a |
| <a name="output_AdminPassword1"></a> [AdminPassword1](#output\_AdminPassword1) | n/a |
| <a name="output_AdminPassword2"></a> [AdminPassword2](#output\_AdminPassword2) | n/a |
<!-- END_TF_DOCS -->