#!/bin/bash

find . -iname "*.tf" -exec dirname {} \; | sort -u | while read dir ; do
    echo " - $dir"
    terraform-docs $dir
done